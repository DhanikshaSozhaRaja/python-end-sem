import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

"""Focused tests for the Vanishing World CSP/AC-3 solver."""

import rules
from csp_solver import CSP, csp_search


def test_ac3_removes_unsupported_values():
    # X and Y must be equal. Y can only be 2, so AC-3 removes 1 from X.
    domains = {"X": {1, 2}, "Y": {2}}
    neighbors = {"X": {"Y"}, "Y": {"X"}}
    problem = CSP(
        domains,
        neighbors,
        lambda xi, x, xj, y: x == y,
    )
    assert problem.ac3(domains)
    assert domains == {"X": {2}, "Y": {2}}


def test_csp_solution_is_a_valid_game_solution():
    solution, nodes = csp_search(max_nodes=100000)
    assert solution is not None
    assert nodes > 0

    state = rules.create_initial_state()
    for direction in solution:
        state = rules.move_state(state, direction)
        assert state[3] != "lost"

    assert rules.is_goal_state(state)


if __name__ == "__main__":
    test_ac3_removes_unsupported_values()
    test_csp_solution_is_a_valid_game_solution()
    print("CSP/AC-3 tests passed.")
