import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

"""Smoke tests for the available search algorithms."""

from rules import create_initial_state, move_state, is_goal_state
from ai_search import bfs_search, dfs_search, iddfs_search, greedy_search, a_star_search
from csp_solver import csp_search


def test_search_algorithms_return_valid_paths():
    state = create_initial_state()
    algorithms = [
        ("BFS", bfs_search),
        ("DFS", dfs_search),
        ("IDDFS", iddfs_search),
        ("Greedy", greedy_search),
        ("A*", a_star_search),
        ("CSP + AC-3", csp_search),
    ]
    for name, algorithm in algorithms:
        path, nodes = algorithm(start_state=state, max_nodes=100000)
        assert nodes >= 0, name
        if path is None:
            continue
        current = state
        for direction in path:
            current = move_state(current, direction)
            assert current is not None, (name, direction)
            assert current[3] != "lost", name
        assert is_goal_state(current), name


if __name__ == "__main__":
    test_search_algorithms_return_valid_paths()
    print("Search smoke tests passed.")
