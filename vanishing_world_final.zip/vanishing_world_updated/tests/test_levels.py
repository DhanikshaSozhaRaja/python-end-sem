import sys
from pathlib import Path

# Add the project root directory to Python's import path.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


import rules

def test_generated_levels_are_solvable():
    import copy

    saved = {
        name: copy.deepcopy(getattr(rules, name))
        for name in (
            "ROWS", "COLS", "START_PLAYER", "START_CRYSTALS", "EXIT_TILE",
            "WALLS", "SPECIAL_TILES", "GUARANTEED_PATH", "LEVEL_NUMBER",
            "CRYSTAL_COUNT", "DIFFICULTY",
        )
    }
    try:
        for level in [1, 4, 7, 10, 13]:
            rules.LEVEL_NUMBER = level
            state = rules.generate_new_level(advance_level=False)
            print(
                f"Level: {rules.get_level_number()}, "
                f"Board: {rules.ROWS}x{rules.COLS}, "
                f"Walls: {len(rules.WALLS)}, "
                f"Crystals: {len(rules.get_start_crystals())}, "
                f"Solvable: {rules.has_solution()}"
            )
            assert rules.has_solution()
            assert state[0] == rules.START_PLAYER
    finally:
        for name, value in saved.items():
            current = getattr(rules, name)
            if isinstance(current, set):
                current.clear()
                current.update(value)
            else:
                setattr(rules, name, value)


if __name__ == "__main__":
    test_generated_levels_are_solvable()
