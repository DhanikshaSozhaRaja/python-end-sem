@echo off
setlocal
cd /d "%~dp0"

set PYTHON=python
py -3.11 --version >nul 2>nul
if not errorlevel 1 set PYTHON=py -3.11

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto error
)

echo Installing or checking dependencies...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error

echo Starting Vanishing World...
".venv\Scripts\python.exe" main.py
if errorlevel 1 goto error

goto end

:error
echo.
echo Something went wrong. Check that Python 3.11 is installed and internet is available for the first dependency installation.
pause

:end
endlocal
