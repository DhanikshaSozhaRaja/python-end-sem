# Vanishing World — AI Puzzle-Survival Game

A Python/Pygame puzzle game in which the player collects every crystal and reaches the exit while every tile left behind disappears. The project includes manual play, AI playback, hints, algorithm comparison, AI-vs-human turn-taking, and a CSP solver using AC-3 plus backtracking.

## Requirements

- Windows 10/11 (or another platform that supports Pygame)
- Python 3.11 recommended
- Pygame 2.6.1 (installed from `requirements.txt`)

## Run on Windows

1. Extract the ZIP file to a normal folder.
2. Open that folder in VS Code or File Explorer.
3. Double-click `run_game.bat`, or run these commands in the project folder:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

If the `py` launcher is unavailable, replace `py -3.11` with `python`.

## Controls

| Key | Action |
|---|---|
| Arrow keys | Move one tile |
| 1 | BFS playback |
| 2 | DFS playback |
| 3 | IDDFS playback |
| 4 | Greedy Best-First playback |
| 5 | A* playback |
| 6 | CSP + AC-3 playback |
| H | Request an A* hint (3 per level) |
| P | Pause / resume |
| R | Restart current level |
| N | Next level (after win or an invalid level) |
| C | Open / close algorithm comparison after a win |
| V | Start AI-vs-human mode |
| Q | Leave AI-vs-human mode |
| F1 / F2 / F3 | Easy / Medium / Hard |

The menus at the top of the game provide the same main actions.

## AI methods

- Breadth-First Search (BFS)
- Depth-First Search (DFS)
- Iterative Deepening DFS (IDDFS)
- Greedy Best-First Search
- A* Search
- Constraint Satisfaction Problem (CSP), using AC-3 arc consistency and backtracking

The AI must collect all crystals before reaching the exit. In normal manual play, the human player can reach the exit after collecting at least one crystal. AI-vs-human challenge mode uses the same all-crystals objective for both participants so move-quality percentages are comparable.

## Project files

- `main.py` — Pygame interface, event handling, game modes, playback, and results
- `rules.py` — game state, movement rules, level generation, and solvability validation
- `ai_search.py` — graph-search algorithms, heuristics, and move-quality evaluation
- `csp_solver.py` — CSP model, AC-3, and backtracking search
- `compare_algorithms.py` — measured algorithm comparison and result caching
- `tests/` — rule, level, search, and CSP tests

## Run tests

```bat
python -m pip install -r requirements.txt
python -m pytest -q
```

The automated tests validate game rules, generated-level solvability, search paths, and the CSP/AC-3 solver.
