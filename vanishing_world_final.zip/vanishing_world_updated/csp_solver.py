"""Constraint-based solver for Vanishing World.

The path is represented by variables X0..Xk, where each variable is the
board position occupied at one time step. Domains contain traversable tiles.
Binary constraints enforce legal adjacency and all-different positions.
AC-3 enforces arc consistency; backtracking handles the global requirement
that every crystal is visited at least once.
"""

from collections import deque

import rules
from ai_search import SearchLimitReached


class CSP:
    """Small binary CSP with AC-3 propagation and backtracking search."""

    def __init__(self, domains, neighbors, constraint):
        self.domains = {var: set(values) for var, values in domains.items()}
        self.neighbors = {var: set(values) for var, values in neighbors.items()}
        self.constraint = constraint

    def revise(self, domains, xi, xj):
        """Remove values in Xi that have no supporting value in Xj."""
        revised = False
        supported = set()
        for x in domains[xi]:
            if any(self.constraint(xi, x, xj, y) for y in domains[xj]):
                supported.add(x)
        if supported != domains[xi]:
            domains[xi] = supported
            revised = True
        return revised

    def ac3(self, domains, queue=None):
        """Enforce arc consistency. Return False if a domain becomes empty."""
        if queue is None:
            queue = deque(
                (xi, xj)
                for xi in self.neighbors
                for xj in self.neighbors[xi]
            )
        else:
            queue = deque(queue)

        while queue:
            xi, xj = queue.popleft()
            if self.revise(domains, xi, xj):
                if not domains[xi]:
                    return False
                for xk in self.neighbors[xi] - {xj}:
                    queue.append((xk, xi))
        return True

    def backtrack(self, domains, crystals, assigned_count):
        """MRV backtracking with AC-3 after every assignment."""
        if all(len(values) == 1 for values in domains.values()):
            assignment = {var: next(iter(values)) for var, values in domains.items()}
            if crystals.issubset(set(assignment.values())):
                return assignment
            return None

        # A crystal absent from all remaining domains can no longer be visited.
        possible_positions = set().union(*domains.values())
        if not crystals.issubset(possible_positions):
            return None

        unassigned = [v for v, values in domains.items() if len(values) > 1]
        var = min(unassigned, key=lambda v: len(domains[v]))

        for value in sorted(domains[var]):
            assigned_count[0] += 1
            if (
                assigned_count[1] is not None
                and assigned_count[0] > assigned_count[1]
            ):
                raise SearchLimitReached(assigned_count[0] - 1)

            new_domains = {v: set(values) for v, values in domains.items()}
            new_domains[var] = {value}

            # Propagate the new assignment through all binary constraints.
            if self.ac3(new_domains):
                result = self.backtrack(new_domains, crystals, assigned_count)
                if result is not None:
                    return result

        return None


def _build_csp(start_state, path_length):
    player, vanished, crystals, status = start_state
    exit_tile = rules.get_exit_tile()

    walkable = {
        (r, c)
        for r in range(rules.ROWS)
        for c in range(rules.COLS)
        if (r, c) not in rules.WALLS and (r, c) not in vanished
    }
    if player not in walkable or exit_tile not in walkable:
        return None

    domains = {i: set(walkable) for i in range(path_length + 1)}
    domains[0] = {player}
    domains[path_length] = {exit_tile}

    neighbors = {i: set() for i in domains}
    for i in domains:
        # Every pair of time variables must have different positions.
        for j in domains:
            if i != j:
                neighbors[i].add(j)
        # Consecutive positions must be orthogonally adjacent.
        if i + 1 in domains:
            neighbors[i].add(i + 1)
        if i - 1 in domains:
            neighbors[i].add(i - 1)

    def constraint(xi, x, xj, y):
        if xi != xj and x == y:
            return False
        if abs(xi - xj) == 1:
            return abs(x[0] - y[0]) + abs(x[1] - y[1]) == 1
        return True

    return CSP(domains, neighbors, constraint)


def csp_search(start_state=None, max_nodes=100000):
    """Solve the current level using CSP + AC-3 + backtracking.

    Returns (list_of_direction_names_or_None, assignment_attempts).
    The path length is increased until a valid route is found.
    """
    if start_state is None:
        start_state = rules.create_initial_state()

    player, vanished, crystals, status = start_state
    if status != "playing":
        return None, 0

    available = (
        rules.ROWS * rules.COLS
        - len(rules.WALLS)
        - len(vanished)
    )
    if available <= 1:
        return None, 0

    # A route needs at least one position for each remaining crystal and exit.
    minimum_moves = max(1, len(crystals) + 1)
    attempts = [0, max_nodes]

    for path_length in range(minimum_moves, available):
        csp = _build_csp(start_state, path_length)
        if csp is None:
            continue

        domains = {v: set(values) for v, values in csp.domains.items()}
        if not csp.ac3(domains):
            continue

        assignment = csp.backtrack(domains, crystals, attempts)
        if assignment is None:
            continue

        positions = [assignment[i] for i in range(path_length + 1)]
        directions = []
        valid = True
        for current, destination in zip(positions, positions[1:]):
            delta = (destination[0] - current[0], destination[1] - current[1])
            direction = next(
                (name for name, vector in rules.DIRECTIONS.items() if vector == delta),
                None,
            )
            if direction is None:
                valid = False
                break
            directions.append(direction)

        if not valid:
            continue

        # Final validation against the actual game transition rules is essential.
        state = start_state
        for direction in directions:
            state = rules.move_state(state, direction)
            if state[3] == "lost":
                valid = False
                break
        if valid and rules.is_goal_state(state):
            return directions, attempts[0]

    return None, attempts[0]


# Explicit name for the combined method shown in the game's menu.
ac3_backtracking_search = csp_search
